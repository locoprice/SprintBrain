// ── SPRINTBRAIN BACKGROUND SERVICE WORKER ─────────────────────────

const DEFAULT_SNIPPETS = [
  {
    id: 's1', shortcut: '/quoteEN', title: 'BOOKING QUOTE EN', lang: 'EN', cat: 'booking',
    fieldCfg: {
      OTA_PRICE: { type: 'number', default: '0' },
      YOUR_PRICE: { type: 'number', default: '0' },
      PAYMENT_TERMS: { type: 'dd', opts: 'Full payment upon confirmation\n50% deposit + balance 40 days before check-in' }
    },
    body: 'Original Accommodation Price: {OTA_PRICE} €\n★ Your Price: {YOUR_PRICE} €\n{if:OTA_PRICE > 0}✓ You save: {=OTA_PRICE - YOUR_PRICE} € (-{=round((OTA_PRICE - YOUR_PRICE) / OTA_PRICE * 100)}%)\n✓ You also save: OTA service fees (typically 12-18%){endif}\n✓ Discount codes: Not valid\n✓ Payment terms: {PAYMENT_TERMS}\n\nPAYMENT OPTIONS\n- Bank Transfer: {=YOUR_PRICE - 25} € ❤️ Loved by our guests\n- Card: {=round(YOUR_PRICE * 1.03)} €\n\n🔗 Other payment methods → leibtour.com/faqs/booking-process\n\n[Pay by bank transfer and save {=OTA_PRICE - YOUR_PRICE} € + {=round(YOUR_PRICE * 0.03) + 25} € = {=OTA_PRICE - YOUR_PRICE + round(YOUR_PRICE * 0.03) + 25} € total]'
  },
  {
    id: 's2', shortcut: '/quoteES', title: 'PRESUPUESTO B2C', lang: 'ES', cat: 'booking',
    fieldCfg: {
      OTA_PRICE: { type: 'number', default: '0' },
      YOUR_PRICE: { type: 'number', default: '0' },
      PAYMENT_TERMS: { type: 'dd', opts: 'Pago completo a la confirmación\n50% depósito + saldo 40 días antes' }
    },
    body: 'Precio OTA: {OTA_PRICE} €\n★ Tu Precio: {YOUR_PRICE} €\n{if:OTA_PRICE > 0}✓ Ahorras: {=OTA_PRICE - YOUR_PRICE} € (-{=round((OTA_PRICE - YOUR_PRICE) / OTA_PRICE * 100)}%)\n✓ También ahorras comisiones OTA (12-18%){endif}\n✓ Términos: {PAYMENT_TERMS}\n\nPAGO\n- Transferencia: {=YOUR_PRICE - 25} € ❤️\n- Tarjeta: {=round(YOUR_PRICE * 1.03)} €'
  },
  {
    id: 's3', shortcut: '/quoteIT', title: 'PREVENTIVO B2C', lang: 'IT', cat: 'booking',
    fieldCfg: {
      OTA_PRICE: { type: 'number', default: '0' },
      YOUR_PRICE: { type: 'number', default: '0' },
      PAYMENT_TERMS: { type: 'dd', opts: 'Pagamento completo alla conferma\n50% deposito + saldo 40 giorni prima' }
    },
    body: 'Prezzo OTA: {OTA_PRICE} €\n★ Il Tuo Prezzo: {YOUR_PRICE} €\n{if:OTA_PRICE > 0}✓ Risparmi: {=OTA_PRICE - YOUR_PRICE} € (-{=round((OTA_PRICE - YOUR_PRICE) / OTA_PRICE * 100)}%)\n✓ Risparmi anche commissioni OTA (12-18%){endif}\n✓ Termini: {PAYMENT_TERMS}\n\nPAGAMENTO\n- Bonifico: {=YOUR_PRICE - 25} € ❤️\n- Carta: {=round(YOUR_PRICE * 1.03)} €'
  },
  {
    id: 's4', shortcut: '/checkin', title: 'CHECK-IN EN', lang: 'EN', cat: 'guest',
    fieldCfg: {
      property_name: { type: 'dd', opts: 'Casa Duquesa\nVilla Santa Eulalia\nApartment San Antonio' },
      CHECKIN: { type: 'date' },
      CHECKOUT: { type: 'date' }
    },
    body: 'Dear {guest_name},\n\nWelcome to {property_name}! 🌅\n\n🔑 Check-in: {CHECKIN} at 16:00\n🔑 Check-out: {CHECKOUT} at 11:00\nKeys: {key_location}\n\n📍 {property_address}\n📱 Emergency: +34 {phone_number}\n\nEnjoy Ibiza!\nLeibTour Team'
  },
  {
    id: 's5', shortcut: '/review', title: 'REVIEW REQUEST EN', lang: 'EN', cat: 'guest',
    fieldCfg: {
      property_name: { type: 'dd', opts: 'Casa Duquesa\nVilla Santa Eulalia\nApartment San Antonio' }
    },
    body: 'Dear {guest_name},\n\nThank you for staying at {property_name}! 🌟\n\nJust 2 minutes on Airbnb means the world to us.\n\n👉 {review_link}\n\nWarm regards,\nLeibTour Team'
  }
];

// Seed on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get('snippets', (data) => {
    if (!data.snippets || data.snippets.length === 0) {
      chrome.storage.sync.set({ snippets: DEFAULT_SNIPPETS }, () => {
        console.log('[Sprintbrain] Snippets seeded:', DEFAULT_SNIPPETS.length);
      });
    }
  });
});

// Message handler
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_SNIPPETS') {
    chrome.storage.sync.get('snippets', (data) => {
      const snips = data.snippets && data.snippets.length > 0
        ? data.snippets
        : DEFAULT_SNIPPETS;
      sendResponse({ snippets: snips });
    });
    return true;
  }
  if (msg.type === 'SAVE_SNIPPETS') {
    chrome.storage.sync.set({ snippets: msg.snippets }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }
});
